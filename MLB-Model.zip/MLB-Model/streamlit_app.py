import streamlit as st
import pandas as pd
import os
from datetime import datetime
import matplotlib.pyplot as plt

st.set_page_config(page_title="⚾ NRFI Dashboard", layout="wide")
st.title("⚾ MLB NRFI/YRFI Model Dashboard")

# Tabs
tab1, tab2 = st.tabs(["🔮 Today's Predictions", "📊 Prediction Log"])

# === TAB 1: Today’s Predictions ===
with tab1:
    st.subheader("Today's Matchups")

    if os.path.exists("nrfi_model.pkl"):
        try:
            from predict_today import predict_today  # This must return a DataFrame
            df_today = predict_today()
            if df_today.empty:
                st.warning("No valid matchups found today.")
            else:
                st.success(f"✅ {len(df_today)} games predicted today.")
                st.dataframe(df_today, use_container_width=True)
        except Exception as e:
            st.error(f"Prediction error: {e}")
    else:
        st.warning("No model found. Run your daily pipeline to train.")

# === TAB 2: Historical Prediction Log ===
with tab2:
    st.subheader("NRFI Model Log History")

    if os.path.exists("nrfi_predictions_log.csv"):
        df = pd.read_csv("nrfi_predictions_log.csv")
        df["date"] = pd.to_datetime(df["date"])
        df = df.sort_values("date", ascending=False)

        # Summary Stats
        total = len(df)
        correct = (df["missed"] == 0).sum()
        missed = (df["missed"] == 1).sum()
        win_rate = correct / total * 100 if total > 0 else 0

        st.markdown(f"""
        #### 📈 Overall Stats
        - Total Predictions: **{total}**
        - Correct Predictions: **{correct}**
        - Missed Predictions: **{missed}**
        - Win Rate: **{win_rate:.2f}%**
        """)

        # Filters
        with st.expander("🔎 Filters", expanded=True):
            teams = sorted(set(sum(df["matchup"].str.split(" @ ").tolist(), [])))
            team_filter = st.multiselect("Filter by Team", teams)
            date_range = st.date_input("Filter by Date Range", [])

            filtered_df = df.copy()

            if team_filter:
                filtered_df = filtered_df[filtered_df["matchup"].str.contains("|".join(team_filter))]

            if len(date_range) == 2:
                start, end = pd.to_datetime(date_range)
                filtered_df = filtered_df[filtered_df["date"].between(start, end)]

            if st.checkbox("Show only missed predictions"):
                filtered_df = filtered_df[filtered_df["missed"] == 1]

        st.dataframe(filtered_df, use_container_width=True)

        # Charts
        with st.expander("📊 Charts"):
            st.markdown("#### Miss Rate Over Time")
            daily_stats = (
                df.groupby("date")
                .agg(total=("missed", "count"), missed=("missed", "sum"))
                .reset_index()
            )
            daily_stats["miss_rate"] = daily_stats["missed"] / daily_stats["total"] * 100

            fig, ax = plt.subplots()
            ax.plot(daily_stats["date"], daily_stats["miss_rate"], marker='o')
            ax.set_ylabel("Miss Rate (%)")
            ax.set_xlabel("Date")
            ax.set_title("Daily Miss Rate")
            ax.grid(True)
            st.pyplot(fig)

            st.markdown("#### YRFI Probability Distribution")
            fig2, ax2 = plt.subplots()
            ax2.hist(df["yrfi_prob"], bins=20, color="skyblue", edgecolor="black")
            ax2.set_xlabel("Predicted YRFI Probability")
            ax2.set_ylabel("Number of Games")
            ax2.set_title("Distribution of YRFI Probabilities")
            st.pyplot(fig2)

    else:
        st.warning("No prediction log found. Run your pipeline to generate predictions.")
