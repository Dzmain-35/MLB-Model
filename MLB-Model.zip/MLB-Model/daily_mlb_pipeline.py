import os
import json
import sqlite3
import pandas as pd
import joblib
import statsapi
from datetime import datetime, timedelta
from nrfi_model import build_pitcher_stats, load_nrfi_games_with_pitchers
from nrfi_model_train import train_model

DB_NAME = "mlb_stats.db"
DATA_FOLDER = "data"
LOG_PATH = "nrfi_predictions_log.csv"
MODEL_PATH = "nrfi_model.pkl"

# Step 1: Pull and load yesterday’s data
def get_daily_mlb_games(date_str):
    games = statsapi.schedule(date=date_str, sportId=1)
    results = []
    for game in games:
        summary = {
            "date": date_str,
            "home_team": game["home_name"],
            "away_team": game["away_name"],
            "home_score": game.get("home_score", None),
            "away_score": game.get("away_score", None),
            "status": game["status"],
            "game_id": game["game_id"],
            "starting_pitchers": {
                "home": game.get("home_probable_pitcher", "Unknown"),
                "away": game.get("away_probable_pitcher", "Unknown")
            }
        }

        # First inning runs
        try:
            linescore = statsapi.get("game_linescore", {"gamePk": game["game_id"]})
            if linescore.get("innings"):
                summary["first_inning_runs"] = {
                    "home": linescore["innings"][0].get("home", {}).get("runs", 0),
                    "away": linescore["innings"][0].get("away", {}).get("runs", 0)
                }
            else:
                summary["first_inning_runs"] = {"home": 0, "away": 0}
        except:
            summary["first_inning_runs"] = {"home": 0, "away": 0}

        # Boxscore
        try:
            box = statsapi.get("game_boxscore", {"gamePk": game["game_id"]})
            players = {**box["teams"]["home"]["players"], **box["teams"]["away"]["players"]}

            summary["player_stats"] = []
            summary["pitcher_stats"] = []

            for p in players.values():
                stats = p.get("stats", {}).get("batting", {})
                if stats.get("atBats", 0) > 0:
                    summary["player_stats"].append({
                        "name": p["person"]["fullName"],
                        "team": p.get("parentTeamName", "Unknown"),
                        "hits": stats.get("hits", 0),
                        "rbi": stats.get("rbi", 0)
                    })

            for p in players.values():
                stats = p.get("stats", {}).get("pitching", {})
                if stats.get("inningsPitched"):
                    summary["pitcher_stats"].append({
                        "name": p["person"]["fullName"],
                        "team": p.get("parentTeamName", "Unknown"),
                        "innings_pitched": stats.get("inningsPitched", "0.0"),
                        "strikeouts": stats.get("strikeOuts", 0),
                        "earned_runs": stats.get("earnedRuns", 0)
                    })
        except:
            summary["player_stats"] = []
            summary["pitcher_stats"] = []

        results.append(summary)
    return results

def insert_data_to_db(games, db_path=DB_NAME):
    def insert_game(cursor, game):
        home_data = game["first_inning_runs"].get("home", 0)
        away_data = game["first_inning_runs"].get("away", 0)

        cursor.execute("""
            INSERT OR IGNORE INTO games (
                id, date, home_team, away_team,
                home_score, away_score,
                home_pitcher, away_pitcher,
                home_1st_runs, away_1st_runs
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            game["game_id"], game["date"], game["home_team"], game["away_team"],
            game["home_score"], game["away_score"],
            game["starting_pitchers"]["home"], game["starting_pitchers"]["away"],
            home_data, away_data
        ))

    def insert_hitters(cursor, game_id, hitters):
        for h in hitters:
            cursor.execute("""
                INSERT INTO hitters (game_id, name, team, hits, rbi)
                VALUES (?, ?, ?, ?, ?)
            """, (game_id, h["name"], h["team"], h["hits"], h["rbi"]))

    def insert_pitchers(cursor, game_id, pitchers):
        for p in pitchers:
            cursor.execute("""
                INSERT INTO pitchers (game_id, name, team, innings_pitched, strikeouts, earned_runs)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (game_id, p["name"], p["team"], p["innings_pitched"], p["strikeouts"], p["earned_runs"]))

    conn = sqlite3.connect(db_path)
    cur = conn.cursor()

    for game in games:
        insert_game(cur, game)
        insert_hitters(cur, game["game_id"], game.get("player_stats", []))
        insert_pitchers(cur, game["game_id"], game.get("pitcher_stats", []))

    conn.commit()
    conn.close()

# Step 2: Evaluate yesterday’s predictions
def evaluate_yesterday_and_log():
    conn = sqlite3.connect(DB_NAME)
    pitchers = pd.read_sql_query("SELECT p.*, g.date FROM pitchers p JOIN games g ON g.id = p.game_id", conn)
    games = pd.read_sql_query("SELECT * FROM games WHERE home_1st_runs IS NOT NULL AND away_1st_runs IS NOT NULL", conn)
    conn.close()

    pitchers = build_pitcher_stats(pitchers)
    games["date"] = pd.to_datetime(games["date"])
    yesterday = datetime.today().date() - timedelta(days=1)
    yesterday_games = games[games["date"] == pd.to_datetime(yesterday)]

    if yesterday_games.empty:
        print("🚫 No results to evaluate for yesterday.")
        return

    model = joblib.load(MODEL_PATH)
    logs = []

    for _, row in yesterday_games.iterrows():
        def pitcher_metrics(df):
            ip = df["ip"].sum()
            if ip == 0: return 4.5, 8.0
            era = df["earned_runs"].sum() / ip * 9
            k9 = df["strikeouts"].sum() / ip * 9
            return era, k9

        def rate(df, col, team, date):
            return df[(df[col] == team) & (df["date"] < date)].tail(20)["home_1st_runs"].gt(0).mean() or 0.5

        hp = row["home_pitcher"]
        ap = row["away_pitcher"]
        date = row["date"]

        hp_data = pitchers[(pitchers["name"] == hp) & (pitchers["date"] < date)]
        ap_data = pitchers[(pitchers["name"] == ap) & (pitchers["date"] < date)]

        h_era, h_k9 = pitcher_metrics(hp_data)
        a_era, a_k9 = pitcher_metrics(ap_data)

        features = pd.DataFrame([{
            "home_pitcher_era": h_era,
            "home_pitcher_k9": h_k9,
            "away_pitcher_era": a_era,
            "away_pitcher_k9": a_k9,
            "home_pitcher_yrfi_rate": (hp_data["earned_runs"] > 0).mean() or 0.5,
            "away_pitcher_yrfi_rate": (ap_data["earned_runs"] > 0).mean() or 0.5,
            "home_team_yrfi_rate": rate(games, "home_team", row["home_team"], date),
            "away_team_yrfi_rate": rate(games, "away_team", row["away_team"], date)
        }])

        prob = model.predict_proba(features)[0][1]
        pred = int(prob >= 0.5)
        actual = int((row["home_1st_runs"] + row["away_1st_runs"]) > 0)

        logs.append({
            "date": date.date(), "game_id": row["id"],
            "matchup": f"{row['away_team']} @ {row['home_team']}",
            "home_pitcher": hp, "away_pitcher": ap,
            "yrfi_prob": round(prob, 3), "predicted_yrfi": pred,
            "actual_yrfi": actual, "missed": int(pred != actual)
        })

    df_log = pd.DataFrame(logs)
    if os.path.exists(LOG_PATH):
        df_log.to_csv(LOG_PATH, mode="a", index=False, header=False)
    else:
        df_log.to_csv(LOG_PATH, index=False)
    print(f"📊 Evaluated {len(df_log)} games and saved to {LOG_PATH}")

# Step 3: Retrain model
def retrain_model():
    print("🧠 Retraining model...")
    train_model(show_plots=False)

# Step 4: Predict today
def predict_today():
    from nrfi_predict_today import predict_today as run_prediction
    print("\n🔮 Running today’s NRFI and strikeout predictions...\n")
    run_prediction()

# Main pipeline
def main():
    print("📦 Starting Daily MLB Pipeline\n")

    # Update database
    yesterday = (datetime.today() - timedelta(days=1)).strftime("%Y-%m-%d")
    games = get_daily_mlb_games(yesterday)
    os.makedirs(DATA_FOLDER, exist_ok=True)
    with open(f"{DATA_FOLDER}/mlb_games_{yesterday}.json", "w") as f:
        json.dump(games, f, indent=2)
    insert_data_to_db(games)

    # Evaluate and log yesterday
    evaluate_yesterday_and_log()

    # Retrain model
    retrain_model()

    # Predict today's matchups
    predict_today()

if __name__ == "__main__":
    main()
