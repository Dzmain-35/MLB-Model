import os
import json
import datetime
import time
import sqlite3
import statsapi
from nrfi_model_train import train_model

DB_NAME = "mlb_stats.db"
DATA_FOLDER = "data"

def get_daily_mlb_games(date_str):
    games = statsapi.schedule(date=date_str, sportId=1)
    results = []

    for game in games:
        summary = {
            "date": date_str,
            "home_team": game["home_name"],
            "away_team": game["away_name"],
            "home_score": game.get("home_score", None),
            "away_score": game.get("away_score", None),
            "status": game["status"],
            "game_id": game["game_id"],
            "starting_pitchers": {
                "home": game.get("home_probable_pitcher", "Unknown"),
                "away": game.get("away_probable_pitcher", "Unknown")
            }
        }

        # 1st inning runs
        try:
            linescore = statsapi.get("game_linescore", {"gamePk": game["game_id"]})
            if linescore.get("innings"):
                summary["first_inning_runs"] = {
                    "home": linescore["innings"][0].get("home", {}).get("runs", 0),
                    "away": linescore["innings"][0].get("away", {}).get("runs", 0)
                }
            else:
                summary["first_inning_runs"] = {"home": 0, "away": 0}
        except:
            summary["first_inning_runs"] = {"home": 0, "away": 0}

        # Boxscore
        try:
            boxscore = statsapi.get("game_boxscore", {"gamePk": game["game_id"]})
            players = {**boxscore["teams"]["home"]["players"], **boxscore["teams"]["away"]["players"]}

            # Batters
            summary["player_stats"] = []
            for p in players.values():
                stats = p.get("stats", {}).get("batting", {})
                if stats.get("atBats", 0) > 0:
                    summary["player_stats"].append({
                        "name": p["person"]["fullName"],
                        "team": p.get("parentTeamName", "Unknown"),
                        "hits": stats.get("hits", 0),
                        "rbi": stats.get("rbi", 0)
                    })

            # Pitchers
            summary["pitcher_stats"] = []
            for p in players.values():
                stats = p.get("stats", {}).get("pitching", {})
                if stats.get("inningsPitched"):
                    summary["pitcher_stats"].append({
                        "name": p["person"]["fullName"],
                        "team": p.get("parentTeamName", "Unknown"),
                        "innings_pitched": stats.get("inningsPitched", "0.0"),
                        "strikeouts": stats.get("strikeOuts", 0),
                        "earned_runs": stats.get("earnedRuns", 0)
                    })

        except:
            summary["player_stats"] = []
            summary["pitcher_stats"] = []

        results.append(summary)

    return results

def insert_game(cursor, game):
    def extract_runs(side_data):
        if isinstance(side_data, dict):
            return side_data.get("runs", 0)
        elif isinstance(side_data, int):
            return side_data
        return 0

    home_data = game.get("first_inning_runs", {}).get("home", {})
    away_data = game.get("first_inning_runs", {}).get("away", {})
    first_inning_home = extract_runs(home_data)
    first_inning_away = extract_runs(away_data)

    cursor.execute('''
        INSERT OR IGNORE INTO games (
            id, date, home_team, away_team,
            home_score, away_score,
            home_pitcher, away_pitcher,
            home_1st_runs, away_1st_runs
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (
        game["game_id"],
        game["date"],
        game["home_team"],
        game["away_team"],
        game["home_score"],
        game["away_score"],
        game["starting_pitchers"]["home"],
        game["starting_pitchers"]["away"],
        first_inning_home,
        first_inning_away
    ))

def insert_hitters(cursor, game_id, hitters):
    for h in hitters:
        cursor.execute('''
            INSERT INTO hitters (game_id, name, team, hits, rbi)
            VALUES (?, ?, ?, ?, ?)
        ''', (game_id, h["name"], h["team"], h["hits"], h["rbi"]))

def insert_pitchers(cursor, game_id, pitchers):
    for p in pitchers:
        cursor.execute('''
            INSERT INTO pitchers (game_id, name, team, innings_pitched, strikeouts, earned_runs)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (game_id, p["name"], p["team"], p["innings_pitched"], p["strikeouts"], p["earned_runs"]))

def update_yesterday():
    os.makedirs(DATA_FOLDER, exist_ok=True)
    date_obj = datetime.date.today() - datetime.timedelta(days=1)
    date_str = date_obj.strftime('%Y-%m-%d')
    file_path = f"{DATA_FOLDER}/mlb_games_{date_str}.json"

    if os.path.exists(file_path):
        print(f"⏭️ {date_str}: already exists.")
    else:
        games = get_daily_mlb_games(date_str)
        with open(file_path, "w") as f:
            json.dump(games, f, indent=2)
        print(f"✅ {date_str}: saved {len(games)} games.")

    with open(file_path, "r") as f:
        games = json.load(f)

    conn = sqlite3.connect(DB_NAME)
    cur = conn.cursor()
    count = 0

    for game in games:
        try:
            insert_game(cur, game)
            insert_hitters(cur, game["game_id"], game.get("player_stats", []))
            insert_pitchers(cur, game["game_id"], game.get("pitcher_stats", []))
            count += 1
        except Exception as e:
            print(f"❌ Game {game['game_id']} failed: {e}")

    conn.commit()
    conn.close()

    print(f"📦 {count} games loaded into database.")

if __name__ == "__main__":
    update_yesterday()
    print("\n🔁 Retraining NRFI model...")
    train_model(show_plots=False)

