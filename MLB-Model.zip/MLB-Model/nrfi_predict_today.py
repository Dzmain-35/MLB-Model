import statsapi
import sqlite3
import pandas as pd
import joblib
from datetime import datetime, timedelta
from nrfi_model import build_pitcher_stats, safe_parse_ip
import os

# Load trained model
model = joblib.load("nrfi_model.pkl")

def get_historical_data():
    conn = sqlite3.connect("mlb_stats.db")

    pitchers = pd.read_sql_query("""
        SELECT p.*, g.date
        FROM pitchers p
        JOIN games g ON g.id = p.game_id
    """, conn)

    games = pd.read_sql_query("""
        SELECT *
        FROM games
        WHERE home_1st_runs IS NOT NULL AND away_1st_runs IS NOT NULL
    """, conn)

    conn.close()
    pitchers = build_pitcher_stats(pitchers)
    games["date"] = pd.to_datetime(games["date"])
    return pitchers, games

def pitcher_yrfi_rate(df, name, before_date):
    games = df[(df["name"] == name) & (df["date"] < before_date)]
    return (games["earned_runs"] > 0).mean() if not games.empty else 0.5

def pitcher_metrics(df):
    ip = df["ip"].sum()
    if ip == 0:
        return 4.5, 8.0
    era = df["earned_runs"].sum() / ip * 9
    k9 = df["strikeouts"].sum() / ip * 9
    return era, k9

def team_yrfi_rate(df, team_col, run_col, team, date):
    games = df[(df[team_col] == team) & (df["date"] < date)].tail(20)
    return (games[run_col] > 0).mean() if not games.empty else 0.5

def get_yesterdays_games(games_df):
    yesterday = pd.to_datetime(datetime.today().date() - timedelta(days=1))
    return games_df[games_df["date"] == yesterday]

def predict_and_log_yesterday():
    print("📅 Evaluating yesterday's NRFI/YRFI results...\n")

    pitchers, games = get_historical_data()
    yesterday_games = get_yesterdays_games(games)

    if yesterday_games.empty:
        print("🚫 No completed games found for yesterday.")
        return

    predictions = []

    for _, row in yesterday_games.iterrows():
        date = row["date"]
        hp = row["home_pitcher"]
        ap = row["away_pitcher"]

        if not hp or not ap:
            continue

        home_p_stats = pitchers[(pitchers["name"] == hp) & (pitchers["date"] < date)]
        away_p_stats = pitchers[(pitchers["name"] == ap) & (pitchers["date"] < date)]

        home_era, home_k9 = pitcher_metrics(home_p_stats)
        away_era, away_k9 = pitcher_metrics(away_p_stats)

        home_pitcher_yrfi = pitcher_yrfi_rate(pitchers, hp, date)
        away_pitcher_yrfi = pitcher_yrfi_rate(pitchers, ap, date)

        home_team_rate = team_yrfi_rate(games, "home_team", "home_1st_runs", row["home_team"], date)
        away_team_rate = team_yrfi_rate(games, "away_team", "away_1st_runs", row["away_team"], date)

        features = pd.DataFrame([{
            "home_pitcher_era": home_era,
            "home_pitcher_k9": home_k9,
            "away_pitcher_era": away_era,
            "away_pitcher_k9": away_k9,
            "home_pitcher_yrfi_rate": home_pitcher_yrfi,
            "away_pitcher_yrfi_rate": away_pitcher_yrfi,
            "home_team_yrfi_rate": home_team_rate,
            "away_team_yrfi_rate": away_team_rate
        }])

        yrfi_prob = model.predict_proba(features)[0][1]
        prediction = 1 if yrfi_prob >= 0.5 else 0
        actual = 1 if (row["home_1st_runs"] + row["away_1st_runs"]) > 0 else 0

        predictions.append({
            "date": date.date(),
            "game_id": row["id"],
            "matchup": f"{row['away_team']} @ {row['home_team']}",
            "home_pitcher": hp,
            "away_pitcher": ap,
            "yrfi_prob": round(yrfi_prob, 3),
            "predicted_yrfi": prediction,
            "actual_yrfi": actual,
            "missed": int(prediction != actual)
        })

    df = pd.DataFrame(predictions)
    print(df.to_string(index=False))

    # Save to log
    log_path = "nrfi_predictions_log.csv"
    if os.path.exists(log_path):
        df.to_csv(log_path, mode="a", index=False, header=False)
    else:
        df.to_csv(log_path, index=False)

    print(f"\n📝 Appended {len(df)} predictions to {log_path}")

